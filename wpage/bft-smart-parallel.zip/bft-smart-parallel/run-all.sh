rm config/currentView &
./p_smartrun.sh demo.list.ListServerMPConcurrent 1 2 1 10000 true true &
./p_smartrun.sh demo.list.ListServerMPConcurrent 2 2 1 10000 true true &
./p_smartrun.sh demo.list.ListServerMPConcurrent 3 2 1 10000 true true &
./p_smartrun.sh demo.list.ListServerMPConcurrent 4 2 1 10000 true true &
./p_smartrun.sh demo.list.ListClientMO 1 1 10 1000 100000 true 1000 &
