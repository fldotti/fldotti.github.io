/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.ts;


import bftsmart.tom.ParallelServiceProxy;
import parallelism.ParallelMapping;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author alchieri
 */
public class BFTTupleSpace {

    static final int OUT = 1;
    static final int INP = 2;
    static final int RDP = 3;
    static final int CAS = 4;


    static final String WILDCARD = "*";

    protected ParallelServiceProxy proxy = null;
    protected ByteArrayOutputStream out = null;

    protected boolean parallel = false;


    public BFTTupleSpace(int id, boolean parallelExecution) {
        proxy = new ParallelServiceProxy(id);
        this.parallel = parallelExecution;
    }


    public void out(Tuple tuple) {
        try {
            out = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(out);
            dos.writeInt(OUT);
            ObjectOutputStream out1 = new ObjectOutputStream(out);
            out1.writeObject(tuple);
            out1.close();
            byte[] rep = null;
            if (parallel) {
                rep = proxy.invokeParallel(out.toByteArray(), ParallelMapping.SYNC_ALL);
            } else {
                rep = proxy.invokeOrdered(out.toByteArray());
            }
            ByteArrayInputStream bis = new ByteArrayInputStream(rep);
            ObjectInputStream in = new ObjectInputStream(bis);
            boolean ret = in.readBoolean();
            in.close();
            //return ret;

        } catch (IOException ex) {
            ex.printStackTrace();
            //return false;
        }
    }

    public Tuple rdp(Tuple template) {
        try {
            out = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(out);
            dos.writeInt(RDP);
            ObjectOutputStream out1 = new ObjectOutputStream(out);
            out1.writeObject(template);
            out1.close();
            byte[] rep = null;
            if (parallel) {
                rep = proxy.invokeParallel(out.toByteArray(), ParallelMapping.CONC_ALL);
            } else {
                rep = proxy.invokeOrdered(out.toByteArray());
            }
            ByteArrayInputStream bis = new ByteArrayInputStream(rep);
            ObjectInputStream in = new ObjectInputStream(bis);
            Tuple ret = (Tuple) in.readObject();
            in.close();
            return ret;
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BFTTupleSpace.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    public Tuple inp(Tuple template) {
        try {
            out = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(out);
            dos.writeInt(INP);
            ObjectOutputStream out1 = new ObjectOutputStream(out);
            out1.writeObject(template);
            out1.close();
            byte[] rep = null;
            if (parallel) {
                rep = proxy.invokeParallel(out.toByteArray(), ParallelMapping.SYNC_ALL);
            } else {
                rep = proxy.invokeOrdered(out.toByteArray());
            }
            ByteArrayInputStream bis = new ByteArrayInputStream(rep);
            ObjectInputStream in = new ObjectInputStream(bis);
            Tuple ret = (Tuple) in.readObject();
            in.close();
            return ret;
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(BFTTupleSpace.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }


    public boolean cas(Tuple tuple, Tuple template) {
        try {
            out = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(out);
            dos.writeInt(CAS);
            ObjectOutputStream out1 = new ObjectOutputStream(out);

            out1.writeObject(template);
            out1.writeObject(tuple);
            out1.close();
            byte[] rep = null;
            if (parallel) {
                rep = proxy.invokeParallel(out.toByteArray(), ParallelMapping.CONC_ALL);
            } else {
                rep = proxy.invokeOrdered(out.toByteArray());
            }

            ByteArrayInputStream bis = new ByteArrayInputStream(rep);
            ObjectInputStream in = new ObjectInputStream(bis);
            boolean ret = in.readBoolean();
            in.close();
            return ret;


        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
