/**
 * Copyright (c) 2007-2013 Alysson Bessani, Eduardo Alchieri, Paulo Sousa, and
 * the authors indicated in the @author tags
 * <p>
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * <p>
 * http://www.apache.org/licenses/LICENSE-2.0
 * <p>
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */
package demo.multipartition;

import bftsmart.tom.MessageContext;
import bftsmart.tom.ServiceReplica;
import bftsmart.tom.server.SingleExecutable;
import parallelism.ParallelServiceReplica;

import java.io.*;
import java.util.logging.Level;

public final class Server implements SingleExecutable {


    private ServiceReplica replica;
    //private StateManager stateManager;
    //private ReplicaContext replicaContext;

    //private List<Integer> l = new LinkedList<Integer>();

    //private int myId;
    //private PrintWriter pw;

    //private boolean closed = false;


    private Object partition1;

    private Object partition2;

    private Object partition3;


    public Server(int id, int minThreads, int initThreads, int maxThreads, boolean cbase) {

        if (initThreads <= 0) {
            System.out.println("Replica in sequential execution model.");

            replica = new ServiceReplica(id, this, null);
        } else if (cbase) {
            /*System.out.println("Replica in parallel execution model (CBASE).");
            ConflictDefinition cd = new ConflictDefinition() {
                @Override
                public boolean isDependent(MessageContextPair r1, MessageContextPair r2) {
                    if(r1.message.groupId == ParallelMapping.CONFLICT_ALL ||
                            r2.message.groupId == ParallelMapping.CONFLICT_ALL){
                        return true;
                    }
                    return false;
                }
            };
            
            replica = new CBASEServiceReplica(id, this, null, initThreads, cd);*/
        } else {
            System.out.println("Replica in parallel execution model. -- reconfiguration disabled");

            replica = new ParallelServiceReplica(id, this, null, initThreads);

            //replica = new ParallelServiceReplica(id, this, null, minThreads, initThreads, maxThreads, new LazyPolicy());
            //replica = new ParallelServiceReplica(id, this,this, minThreads, initThreads, maxThreads, new AgressivePolicy());

        }


        System.out.println("Server initialization complete!");
    }

    public static void main(String[] args) {
        if (args.length < 7) {
            System.out.println("Usage: ... ListServer <processId> <minNum threads> <initialNum threads> <maxNum threads> <CBASE?>");
            System.exit(-1);
        }

        int processId = Integer.parseInt(args[0]);
        int interval = Integer.parseInt(args[1]);
        int minNT = Integer.parseInt(args[2]);
        int initialNT = Integer.parseInt(args[3]);
        int maxNT = Integer.parseInt(args[4]);
        int entries = Integer.parseInt(args[5]);

        boolean context = Boolean.parseBoolean(args[6]);

        boolean cbase = Boolean.parseBoolean(args[7]);

        new Server(processId, maxNT, minNT, initialNT, cbase);
    }

    public byte[] executeOrdered(byte[] command, MessageContext msgCtx) {
        return execute(command, msgCtx);
    }

    public byte[] executeUnordered(byte[] command, MessageContext msgCtx) {
        return execute(command, msgCtx);
    }

    public byte[] execute(byte[] command, MessageContext msgCtx) {

        try {
            ByteArrayInputStream in = new ByteArrayInputStream(command);
            ByteArrayOutputStream out = null;
            byte[] reply = null;
            DataInputStream input = new DataInputStream(in);

            int cmd = input.readInt();
            int p = -1;

            switch (cmd) {
                case MultiPartition.WRITE:

                    p = input.readInt();


                    Object value = new ObjectInputStream(in).readObject();

                    if (p == 1) {
                        partition1 = value;
                    } else if (p == 2) {
                        partition2 = value;
                    } else if (p == 3) {
                        partition3 = value;
                    }

                    out = new ByteArrayOutputStream();
                    ObjectOutputStream out1 = new ObjectOutputStream(out);
                    out1.writeBoolean(true);
                    out.flush();
                    out1.flush();
                    reply = out.toByteArray();
                    break;
                case MultiPartition.READ:

                    p = input.readInt();


                    out = new ByteArrayOutputStream();
                    out1 = new ObjectOutputStream(out);


                    if (p == 1) {
                        out1.writeObject(partition1);
                    } else if (p == 2) {
                        out1.writeObject(partition2);
                    } else if (p == 3) {
                        out1.writeObject(partition3);
                    }


                    out.flush();
                    out1.flush();

                    reply = out.toByteArray();
                    break;
                case MultiPartition.READALL:
                    out = new ByteArrayOutputStream();
                    out1 = new ObjectOutputStream(out);


                    out1.writeObject(partition1);
                    out1.writeObject(partition2);
                    out1.writeObject(partition3);


                    out.flush();
                    out1.flush();

                    reply = out.toByteArray();
                    break;
                case MultiPartition.WRITEALL:

                    Object valueAll = new ObjectInputStream(in).readObject();

                    partition1 = valueAll;
                    partition2 = valueAll;
                    partition3 = valueAll;

                    out = new ByteArrayOutputStream();
                    out1 = new ObjectOutputStream(out);
                    out1.writeBoolean(true);
                    out.flush();
                    out1.flush();
                    reply = out.toByteArray();
                    break;
            }
            return reply;
        } catch (Exception ex) {
            java.util.logging.Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }

    }

}
