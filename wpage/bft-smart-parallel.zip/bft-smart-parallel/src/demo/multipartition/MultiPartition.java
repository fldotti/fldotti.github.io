/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.multipartition;

import bftsmart.tom.ParallelAsynchServiceProxy;
import bftsmart.tom.core.messages.TOMMessageType;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

/**
 * @author eduardo
 */
public class MultiPartition {

    static final int WRITE = 1;
    static final int READ = 2;
    static final int WRITEALL = 3;
    static final int READALL = 4;

    private ParallelAsynchServiceProxy proxy = null;
    private ByteArrayOutputStream out = null;

    public MultiPartition(int id) {
        proxy = new ParallelAsynchServiceProxy(id);
    }


    public boolean write(Object o, int partition) {
        try {
            out = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(out);
            dos.writeInt(WRITE);
            //dos.writeInt(key.intValue());

            dos.writeInt(partition);

            ObjectOutputStream out1 = new ObjectOutputStream(out);
            out1.writeObject(o);
            out1.close();
            int id = proxy.invokeParallelAsynchRequest(out.toByteArray(), null, TOMMessageType.ORDERED_REQUEST, partition * 100);
            proxy.cleanAsynchRequest(id);

            return true;

        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean read(int partition) {
        try {
            out = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(out);
            dos.writeInt(READ);
            //dos.writeInt(key.intValue());

            dos.writeInt(partition);


            int id = proxy.invokeParallelAsynchRequest(out.toByteArray(), null, TOMMessageType.ORDERED_REQUEST, partition * 100);
            proxy.cleanAsynchRequest(id);

            return true;


        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean writeAll(Object o) {
        try {
            out = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(out);
            dos.writeInt(WRITEALL);
            //dos.writeInt(key.intValue());


            ObjectOutputStream out1 = new ObjectOutputStream(out);
            out1.writeObject(o);
            out1.close();
            int id = proxy.invokeParallelAsynchRequest(out.toByteArray(), null, TOMMessageType.ORDERED_REQUEST, 90);
            proxy.cleanAsynchRequest(id);

            return true;

        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean readAll() {
        try {
            out = new ByteArrayOutputStream();
            DataOutputStream dos = new DataOutputStream(out);
            dos.writeInt(READALL);
            //dos.writeInt(key.intValue());


            int id = proxy.invokeParallelAsynchRequest(out.toByteArray(), null, TOMMessageType.ORDERED_REQUEST, 80);
            proxy.cleanAsynchRequest(id);

            return true;

        } catch (IOException ex) {
            ex.printStackTrace();
            return false;
        }
    }
}
