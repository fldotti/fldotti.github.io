package parallelism.CBASE.graph.ian;

public enum Vertex {
    MESSAGE, HEAD, TAIL
}
