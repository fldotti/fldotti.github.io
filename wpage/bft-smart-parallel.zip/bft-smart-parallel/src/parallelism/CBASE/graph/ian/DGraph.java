package parallelism.CBASE.graph.ian;


import parallelism.CBASE.graph.Request;


public interface DGraph {
    void insert(Request request) throws InterruptedException;

    Request process() throws InterruptedException;

    void remove(int data) throws InterruptedException;

    String printVL();

}
