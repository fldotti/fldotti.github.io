package parallelism.CBASE.graph;

import parallelism.MessageContextPair;

public interface Parallelizer {
    boolean isDependent(Request thisRequest, Request otherRequest);

    void insert(MessageContextPair request) throws InterruptedException;

    boolean remove(Request request) throws InterruptedException;

    Request nextRequest() throws InterruptedException;

    void clear();

    int countRequests();
}
