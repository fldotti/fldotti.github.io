/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parallelism.CBASE.graph.sequential;

import parallelism.CBASE.ConflictDefinition;
import parallelism.CBASE.DefaultConflictDefinition;
import parallelism.CBASE.graph.Parallelizer;
import parallelism.CBASE.graph.Request;
import parallelism.CBASE.graph.RequestQueue;
import parallelism.CBASE.graph.common.ExecState;
import parallelism.CBASE.graph.common.ReadEmptyQueue;
import parallelism.MessageContextPair;
import parallelism.ParallelMapping;

/**
 * Created by ruda on 31/08/16.
 */

public class ParallelizerImpl implements Parallelizer {

    private RequestQueue requestQueue;

    private int counter = 0;

    private ConflictDefinition conflictDef;

    public ParallelizerImpl(int limit) {
        this(limit, null);
    }

    public ParallelizerImpl(int limit, ConflictDefinition conflictDef) {
        requestQueue = new RequestQueueImpl(limit, this);
        if (conflictDef == null) {
            this.conflictDef = new DefaultConflictDefinition();
        } else {
            this.conflictDef = conflictDef;
        }
    }

    @Override
    public boolean isDependent(Request thisRequest, Request otherRequest) {


        if (thisRequest.getRequest().classId == ParallelMapping.CONFLICT_RECONFIGURATION ||
                otherRequest.getRequest().classId == ParallelMapping.CONFLICT_RECONFIGURATION) {
            return true;
        }

        return this.conflictDef.isDependent(thisRequest.getRequest(), otherRequest.getRequest());

    }

    @Override
    public void insert(MessageContextPair request) throws InterruptedException {

        Request req = new RequestImpl(ExecState.ready, request, counter);
        requestQueue.insert(req);
        counter++;

    }

    @Override
    public boolean remove(Request request) throws InterruptedException {
        try {
            requestQueue.remove(request);
        } catch (ReadEmptyQueue ex) {
            ex.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public Request nextRequest() throws InterruptedException {
        return requestQueue.nextRequest();
    }

    @Override
    public void clear() {
        requestQueue.clear();
    }

    @Override
    public int countRequests() {
        return requestQueue.countRequests();
    }
}