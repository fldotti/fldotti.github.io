/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parallelism.CBASE.graph.common;

/**
 * Created by ruda on 08/09/16.
 */

public enum ExecState {
    blocked,
    ready,
    running,
}