package parallelism.CBASE.graph.common;

public enum GraphAlgorithmDefinition {

    SEQUENTIAL, PARALLEL, PARALLEL_LINKED

}
