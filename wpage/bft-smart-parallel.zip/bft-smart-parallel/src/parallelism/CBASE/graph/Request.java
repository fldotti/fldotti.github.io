package parallelism.CBASE.graph;

import parallelism.CBASE.graph.common.ExecState;
import parallelism.MessageContextPair;

import java.util.ArrayList;

public interface Request {
    int getRequestId();

    MessageContextPair getRequest();

    ExecState getState();

    void setState(ExecState state);

    void addDependency(Request req);

    void removeDependency(Request req);

    int countDependencies();

    void addDependent(Request req);

    void removeDependent(Request req);

    int countDependents();

    ArrayList<Request> getDependents();
}
