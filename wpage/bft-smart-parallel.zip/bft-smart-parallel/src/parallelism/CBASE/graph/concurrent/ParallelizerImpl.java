/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parallelism.CBASE.graph.concurrent;

import parallelism.CBASE.graph.Parallelizer;
import parallelism.CBASE.graph.Request;
import parallelism.CBASE.graph.common.ExecState;
import parallelism.CBASE.graph.ian.VList;
import parallelism.MessageContextPair;

/**
 * Created by ruda on 31/08/16.
 */

public class ParallelizerImpl implements Parallelizer {

    VList graph;

    public ParallelizerImpl(int limit) {
        graph = new VList(limit, 1.0f);
    }

    @Override
    public boolean isDependent(Request thisRequest, Request otherRequest) {
        return graph.isDependent(thisRequest, otherRequest.getRequestId());
    }

    @Override
    public void insert(MessageContextPair request) throws InterruptedException {
        System.out.println(String.format("inserting %d", request.index));
        Request req = new RequestImpl(ExecState.ready, request, request.index);
        graph.insert(req);
    }

    @Override
    public boolean remove(Request request) throws InterruptedException {
        System.out.println(String.format("removing %d", request.getRequestId()));
        graph.remove(request.getRequestId());
        return true;
    }

    @Override
    public Request nextRequest() throws InterruptedException {
        System.out.println("processing next request");
        return graph.process();
    }

    @Override
    public void clear() {
        System.out.println("clearing");
        graph.clear();
    }

    @Override
    public int countRequests() {
        return graph.countRequests();
    }
}