/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parallelism.CBASE.graph.concurrent;

import parallelism.CBASE.graph.Request;
import parallelism.CBASE.graph.common.ExecState;
import parallelism.MessageContextPair;

import java.util.ArrayList;

/**
 * Created by ruda on 01/09/16.
 */


public class RequestImpl implements Request {

    private int rid;
    private MessageContextPair request;
    private ExecState state;
    private ArrayList<Request> dlist;
    private ArrayList<Request> olist;

    RequestImpl(ExecState state, MessageContextPair request, int rid) {
        this.state = state;
        this.request = request;
        this.rid = rid;
        dlist = new ArrayList<>();
        olist = new ArrayList<>();
    }

    @Override
    public int getRequestId() {
        return rid;
    }

    @Override
    public MessageContextPair getRequest() {
        return this.request;
    }

    @Override
    public ExecState getState() {
        return state;
    }

    @Override
    public void setState(ExecState state) {
        this.state = state;
    }

    @Override
    public void addDependency(Request req) {
        dlist.add(req);
    }

    @Override
    public void removeDependency(Request req) {
        dlist.remove(req);
    }

    @Override
    public int countDependencies() {
        return dlist.size();
    }

    @Override
    public void addDependent(Request req) {
        olist.add(req);
    }

    @Override
    public void removeDependent(Request req) {
        olist.remove(req);
    }

    @Override
    public int countDependents() {
        return olist.size();
    }

    @Override
    public ArrayList<Request> getDependents() {
        return olist;
    }

    @Override
    public String toString() {
        return "RequestImpl{" +
                "rid=" + rid +
                ", dlist=" + dlist +
                ", olist=" + olist +
                '}';
    }

}
