package parallelism.CBASE.graph;

import parallelism.CBASE.graph.common.ReadEmptyQueue;

public interface RequestQueue {
    void insert(Request request) throws InterruptedException;

    void remove(Request request) throws ReadEmptyQueue;

    void clear();

    Request nextRequest() throws InterruptedException;

    int countRequests();
}
