/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parallelism.CBASE;

import bftsmart.tom.core.messages.TOMMessage;
import bftsmart.tom.core.messages.TOMMessageType;
import parallelism.CBASE.graph.Parallelizer;
import parallelism.CBASE.graph.Request;
import parallelism.CBASE.graph.common.GraphAlgorithmDefinition;
import parallelism.MessageContextPair;
import parallelism.ParallelMapping;
import parallelism.scheduler.Scheduler;

/**
 * @author eduardo
 */
public class CBASEScheduler implements Scheduler {

    private Parallelizer graph;

    private int numWorkers;

    //private ThroughputStatistics statistics;

    public CBASEScheduler(int numWorkers, int id, GraphAlgorithmDefinition algorithmDefinition) {
        this(null, numWorkers, id, algorithmDefinition);
    }

    public CBASEScheduler(ConflictDefinition cd, int numWorkers, int id, GraphAlgorithmDefinition algorithmDefinition) {
        if (algorithmDefinition == GraphAlgorithmDefinition.SEQUENTIAL)
            graph = new parallelism.CBASE.graph.sequential.ParallelizerImpl(150, cd);
        else if (algorithmDefinition == GraphAlgorithmDefinition.PARALLEL)
            graph = new parallelism.CBASE.graph.concurrent.ParallelizerImpl(150);
        else
            throw new IllegalArgumentException();


        this.numWorkers = numWorkers;

        // statistics = new ThroughputStatistics(1, "results_scheduler_"+id+".txt","SCHEDULER");
    }


    public int getNumWorkers() {
        return this.numWorkers;
    }


    @Override
    public void schedule(MessageContextPair request) {

        //statistics.start();
        //statistics.computeStatistics(0, 1);

        try {
            graph.insert(request);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }

    }

    public Request nextRequest() {

        try {
            return graph.nextRequest();
        } catch (InterruptedException ex) {
            ex.printStackTrace();
            return null;
        }
    }

    public void removeRequest(Request request) {
        try {
            graph.remove(request);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void scheduleReplicaReconfiguration() {

        TOMMessage reconf = new TOMMessage(0, 0, 0, 0, null, 0, TOMMessageType.ORDERED_REQUEST, ParallelMapping.CONFLICT_RECONFIGURATION);
        MessageContextPair m = new MessageContextPair(reconf, ParallelMapping.CONFLICT_RECONFIGURATION, -1, null);

        schedule(m);


    }

    @Override
    public ParallelMapping getMapping() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


}
