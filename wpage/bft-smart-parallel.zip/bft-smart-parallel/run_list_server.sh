./p_smartrun.sh demo.list.ListServer 4 100 2 4 8 1000 true true
